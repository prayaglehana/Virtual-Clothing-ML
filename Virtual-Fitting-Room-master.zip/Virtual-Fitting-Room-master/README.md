# Virtual-Fitting-Room
Visual Studio; Developed a web application to simulate a fitting room for a user to try-on different clothes virtually. Used Augmented Reality and Gesture Recognition based on HAAR Cascades in OpenCV and C++.
